<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      PT. Golet Digital Solusi
    </div>
    <!-- Default to the left -->
    <span>Copyright &copy; 2022 <a href="#"><b>PC Lazisnu Cilacap</b></a>.</span> All rights reserved.
  </footer>