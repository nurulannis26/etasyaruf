<!DOCTYPE html>
<html>

<head>
    <title>REKAP_PENGAJUAN_PENTASYARUFAN_TINGKAT_UMUM_LAZISNU_CILACAP_PERIODE_{{  strtoupper($filter_daterange2)}}.pdf </title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
@php
    [$start, $end] = explode(' - ', $filter_daterange2);
    $startDate = \Carbon\Carbon::parse($start)->locale('id')->isoFormat('D MMMM Y');
    $endDate = \Carbon\Carbon::parse($end)->locale('id')->isoFormat('D MMMM Y');
@endphp

<main>
    <table style="width:100%">
        <tr>
            <td style="width:33%; text-align:left;"><img src="{{ public_path('/images/gocap.png') }}" width="76"
                    height="76"></td>
            <td style="width:33%;text-align:center;"><img src="{{ public_path('/images/logo_lazisnu.png') }}"
                    width="146" height="76"></td>
            <td style="width:33%;text-align:right;"><img src="{{ public_path('/images/siftnu.png') }}" width="146"
                    height="76"></td>
        </tr>
    </table>

    <p style="margin:0pt; text-align:center; font-size:11pt;">
        <b>REKAP PENGAJUAN PENTASYARUFAN TINGKAT UMUM LAZISNU CILACAP</b>
    </p>


    <table style="width: 100%; font-size: 11pt;">
        {{-- paragraf 1 --}}
        <tr>
            <td style="width: 19%"><b>Periode</b></td>
            <td style="width: 1%">:</td>
            <td style="width: 80%">
                {{ $startDate }} - {{ $endDate }}
            </td>
        </tr>
        <tr>
            <td style="width: 19%"><b>Tingkat Pentasyarufan</b></td>
            <td style="width: 1%">:</td>
            <td style="width: 80%">
                {{ $tingkat }}
            </td>
        </tr>

        <tr>
            <td style="width: 19%"><b>Status Pentasyarufan</b></td>
            <td style="width: 1%">:</td>
            <td style="width: 80%">
                {{ $status }}
            </td>
        </tr>
    </table>

    <br>
    <div></div>


    {{-- RENCANA --}}
    <table cellpadding="5" cellspacing="0"
        style="width:100%;border:0.75pt solid #000000;border-collapse:collapse;font-size:10pt;">
        <thead>
            <tr style=" border: 1px solid black;font-weight:bold;background-color:#cbf2d6">
                <td style="width: 3%;vertical-align:middle; text-align:center; border: 1px solid black;">
                    NO</td>
                <td style="width: 20%;vertical-align:middle; text-align:center; border: 1px solid black;">
                    PENGAJUAN
                </td>
                <td style="width: 22%;vertical-align:middle; text-align:center; border: 1px solid black;">
                    PILAR & PROGRAM
                </td>
                <td style="width: 10%;vertical-align:middle; text-align:center; border: 1px solid black;">
                    PENERIMA<br>
                    MANFAAT </td>
                <td style="width: 21%;vertical-align:middle; text-align:center; border: 1px solid black;">
                    MUSTAHIK <br>
                </td>
                <td style="width: 12%;vertical-align:middle; text-align:center; border: 1px solid black;">
                    NOMINAL DISETUJUI</td>
                <td style="width: 12%;vertical-align:middle; text-align:center; border: 1px solid black;">
                    NOMINAL PENCAIRAN</td>

            </tr>
        </thead>

        <tbody>
            @php
                $total_nominal_pengajuan = 0;
                $total_nominal_disetujui = 0;
                $total_nominal_pencairan = 0;

                $total_penerima = 0;
            @endphp
            @foreach ($data as $b)
                @php

                    $jumlah_penerima = App\Http\Controllers\PrintPengajuanController::hitung_jumlah_penerima(
                        $b->id_pengajuan,
                    );
                    $nominal_pengajuan = App\Http\Controllers\PrintPengajuanController::hitung_nominal_pengajuan(
                        $b->id_pengajuan,
                    );
                    $nominal_disetujui = App\Http\Controllers\PrintPengajuanController::hitung_nominal_pengajuan_disetujui(
                        $b->id_pengajuan,
                    );
                    $nominal_pencairan = App\Http\Controllers\PrintPengajuanController::hitung_nominal_pengajuan_pencairan(
                        $b->id_pengajuan,
                    );
                    $nama_pengurus = App\Http\Controllers\PrintPengajuanController::nama_pengurus_pc(
                        $b->pemohon_internal,
                    );
                    $nama_pilar = App\Http\Controllers\PrintPengajuanController::get_nama_pilar($b->id_program_pilar);
                    $nama_kegiatan = App\Http\Controllers\PrintPengajuanController::get_nama_kegiatan(
                        $b->id_program_kegiatan,
                    );
                    $total_nominal_pengajuan += $nominal_pengajuan;
                    $total_nominal_disetujui += $nominal_disetujui;
                    $total_nominal_pencairan += $nominal_pencairan;

                    $total_penerima += $jumlah_penerima;
                @endphp

                <tr>
                    <td style="text-align:center;vertical-align:top; border: 1px solid black;width: 3%;">
                        {{ $loop->iteration }}</td>
                    <td style="text-align:left;vertical-align:top;border: 1px solid black;padding-left:2mm;width: 20%;">
                        <span style="font-size: 12px; font-weight: bold; ">{{ $b->nomor_surat }}
                        </span> <br>
                        @if ($b->opsi_pemohon == 'Entitas')
                            <span class="text-light badge badge-primary">Pemohon Entitas</span>
                        @elseif($b->opsi_pemohon == 'Individu')
                            <span class="text-light badge badge-success">Pemohon Individu</span>
                        @else
                            <span class="text-light badge badge-secondary">Pemohon Internal</span>
                        @endif
                        <table style="width: 100%;font-size:12px;">
                            <tr>
                                <td style="width:50%">Pengajuan</td>
                                <td>
                                    <div style="text-align:left">
                                        Rp{{ number_format($b->nominal_pengajuan, 0, ',', '.') }},-
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="width:50%">Tgl Pengajuan</td>
                                <td>
                                    <div style="text-align:left">
                                        {{ Carbon\Carbon::parse($b->tgl_pengajuan)->isoFormat('D MMMM Y') }}
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="width:50%">Tgl Input</td>
                                <td>
                                    <div style="text-align:left">
                                        {{ Carbon\Carbon::parse($b->created_at)->isoFormat('D MMMM Y') }}
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="width:50%">Pemohon</td>
                                <td class="text-bold" style="vertical-align:top;">
                                    @if ($b->opsi_pemohon == 'Entitas')
                                        {{ $b->nama_entitas }}
                                    @elseif($b->opsi_pemohon == 'Individu')
                                        {{ $b->nama_pemohon }}
                                    @elseif($b->opsi_pemohon == 'Internal')
                                        {{ $nama_pengurus }}
                                    @endif
                                </td>
                            </tr>
                        </table>


                    </td>
                    <td
                        style="text-align:center;vertical-align:top;border: 1px solid black;padding-left:1mm;text-align:left;width: 22%;">
                        <span style="font-size: 12px; font-weight: bold; ">{{ $nama_pilar ?? '-' }}
                        </span> <br>
                        <span style="font-size: 12px; font-weight: bold; ">{{ $nama_kegiatan ?? '-' }}
                        </span> <br>
                        <span style="font-size: 12px; ">{{ $b->pengajuan_note }}
                        </span>
                        <br>
                        <table style="width: 100%;font-size:12px;margin-top:10px;">
                            <tr>
                                <td style="width:62%">Disposisi Program</td>
                                <td>
                                    <div style="text-align:left">
                                        {{ Carbon\Carbon::parse($b->tgl_diserahkan_div_program)->isoFormat('D MMMM Y') }}
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="width:62%">Diserahkan ke Direktur</td>
                                <td>
                                    <div style="text-align:left">
                                        {{ Carbon\Carbon::parse($b->tgl_diserahkan_direktur)->isoFormat('D MMMM Y') }}
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td
                        style="border: 1px solid black;text-align:center;vertical-align:top;text-align:center;width: 10%;">
                        <span style="font-size: 12px; font-weight: bold; ">{{ $jumlah_penerima }}
                        </span> <br>
                        @if ($b->approval_status == 'Disetujui')
                            @if ($b->pil_survey == 'Perlu')
                                @if ($b->status_survey == 'Direncanakan')
                                    <span class="text-light badge badge-warning">Survey Blm Selesai</span>
                                @elseif($b->status_survey == 'Diajukan')
                                    <span class="text-light badge badge-success">Survey Selesai
                                    </span>
                                @endif
                            @elseif($b->pil_survey == 'Tidak Perlu')
                                <span class="text-light badge badge-secondary">Tanpa Survey
                                </span>
                            @else
                                <span class="text-light badge badge-warning">Survey Blm Selesai</span>
                            @endif
                        @else
                            <div class="text-center" style="font-size: 12px;">
                                <span>
                                    Blm Dipilih
                                </span>
                            </div>
                        @endif
                    </td>

                    <td style="border: 1px solid black;text-align:left;vertical-align:top;width: 21%;">
                        @forelse ($mustahik->where('id_pengajuan', $b->id_pengajuan) as $mu)
                        <span style="text-align:left;vertical-align:top;font-size: 12px;">({{ $loop->iteration }}.)</span><br>
                        <span style="text-align:left;vertical-align:top;font-size: 12px;">{{ $mu->nama ?? '-' }}</span><br>
                        <span style="text-align:left;vertical-align:top;font-size: 12px;">No HP&nbsp;&nbsp;: {{ $mu->nohp ?? '-' }}</span><br>
                        <span style="text-align:left;vertical-align:top;font-size: 12px;">NIK&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {{ $mu->nik ?? '-' }}</span><br>
                        <span style="text-align:left;vertical-align:top;font-size: 12px;">Alamat&nbsp;: {{ $mu->alamat ?? '-' }}</span><br>
                    @empty
                        <div style="text-align:center;font-size:12px;">Blm diinput</div>
                    @endforelse                    
                    </td>

                    <td
                        style="border: 1px solid black;padding-left:1mm;padding-right:1mm;text-align:center;vertical-align: top;width: 12%;">
                        <table style="width: 100%;font-size:12px;">
                            <tr>
                                <td style="width:10%">Rp</td>
                                <td>
                                    <div style="text-align:right">
                                        {{ isset($b->nominal_disetujui_pencairan_direktur) ? number_format($b->nominal_disetujui_pencairan_direktur, 0, ',', '.') . ',-' : '-' }}
                                    </div>
                                </td>
                            </tr>
                        </table>
                        <div style="text-align:right; font-size:12px;">
                            {{ isset($b->approval_date_pencairan_direktur) ? Carbon\Carbon::parse($b->approval_date_pencairan_direktur)->isoFormat('D MMMM Y') : '-' }}
                        </div>
                    </td>
                    <td
                        style="border: 1px solid black;padding-left:1mm;padding-right:1mm;text-align:center;vertical-align: top;width: 12%;">

                        <table style="width: 100%;font-size:12px;">
                            <tr>
                                <td style="width:10%">Rp</td>
                                <td>
                                    <div style="text-align:right;">
                                        {{ isset($b->nominal_pencairan) ? number_format($b->nominal_pencairan, 0, ',', '.') . ',-' : '-' }}
                                    </div>
                                </td>
                            </tr>
                        </table>
                        <div style="text-align:right; font-size:12px;">
                            {{ isset($b->tgl_pencairan) ? Carbon\Carbon::parse($b->tgl_pencairan)->isoFormat('D MMMM Y') : '-' }}
                            
                        </div>
                    </td>


                </tr>
            @endforeach

            <tr style="background-color:#cbf2d6;border: 1px solid black;">
                <td style="border-bottom: 1px solid black;padding-left: 2mm;border-right: 1px solid black;"><b> </b>
                </td>
                <td
                    style="border-bottom: 1px solid black;border-left: 1px solid black;border-right: 1px solid black;padding-left: 2mm;">
                    <table style="width: 100%;font-size:12px;">
                        <tr>
                            <td style="width:20%"><b>TOTAL</b></td>
                            <td>
                                <div style="text-align:right;">
                                    <b>Rp{{ number_format($total_nominal_pengajuan, 0, '.', '.') }},-</b>
                                </div>
                            </td>
                        </tr>
                    </table>
                </td>
                <td
                    style="border-bottom: 1px solid black;border-left:1px solid black;border-right:1px solid black;padding-left: 1mm;text-align:center">
                    <b></b>
                </td>
                <td
                    style="border-bottom: 1px solid black;border-left:1px solid black;border-right:1px solid black;padding-left: 1mm;text-align:center">
                    <b>{{ $total_penerima }} </b>
                </td>
                <td style="border-bottom: 1px solid black;padding-left: 2mm;border-right: 1px solid black;"><b> </b>
                </td>
                <td
                    style="border-bottom: 1px solid black;border-left:1px solid black;border-right:1px solid black;padding-left: 1mm;vertical-align: top; text-align:center;">

                    <span
                        style="float:right;"><b>Rp{{ number_format($total_nominal_disetujui, 0, '.', '.') }},-</b></span>
                </td>
                <td
                    style="border-bottom: 1px solid black;border-left:1px solid black;border-right:none;padding-left: 1mm;vertical-align: top; text-align:center;">
                    <span
                        style="float:right;"><b>Rp{{ number_format($total_nominal_pencairan, 0, '.', '.') }},-</b></span>
                </td>


            </tr>
        </tbody>
    </table>
</main>
