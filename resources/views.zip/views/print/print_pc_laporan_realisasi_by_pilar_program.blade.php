
@php
    [$start, $end] = explode(' - ', $filter_daterange2);
    $startDate = \Carbon\Carbon::parse($start)
        ->locale('id')
        ->isoFormat('D MMMM Y');
    $endDate = \Carbon\Carbon::parse($end)
        ->locale('id')
        ->isoFormat('D MMMM Y');
@endphp


<table style="width:100%">
    <tr>
        <td style="width:33%; text-align:left;"><img src="{{ public_path('/images/gocap.png') }}" width="76"
                height="76"></td>
        <td style="width:33%;text-align:center;"><img src="{{ public_path('/images/logo_lazisnu.png') }}" width="146"
                height="76"></td>
        <td style="width:33%;text-align:right;"><img src="{{ public_path('/images/siftnu.png') }}" width="146"
                height="76"></td>
    </tr>
</table>


<table style="width: 100%; font-size: 11pt;">
    {{-- paragraf 1 --}}
    <tr>
        <td style="width: 19%"><b>Periode</b></td>
        <td style="width: 1%">:</td>
        <td style="width: 80%">
            {{ $startDate }} - {{ $endDate }}
        </td>
    </tr>
    <tr>
        <td style="width: 19%"><b>Total Pencairan</b></td>
        <td style="width: 1%">:</td>
        <td style="width: 80%">
            Rp {{ number_format($sum_pencairan, 0, '.', '.') }},-
          
        </td>
    </tr>

    <tr>
        <td style="width: 19%"><b>Total Penerima Manfaat</b></td>
        <td style="width: 1%">:</td>
        <td style="width: 80%">
            {{ $sum_penerima }}
        </td>
    </tr>


</table>

<br>
<div></div>

<table cellpadding="2" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:10pt;">

    <thead>
        <tr style="text-align:center; background-color:#cbf2d6; border: 1px solid black;">
            <td style="width: 3%;vertical-align:middle; border: 1px solid black;"><b>NO</b></td>
            <td style="width: 20%;vertical-align:middle; border: 1px solid black;"><b>NAMA PROGRAM</b></td>
            <td style="width: 18%;vertical-align:middle; border: 1px solid black;"><b>SUMBER DANA</b></td>
            <td style="width: 13%;vertical-align:middle; border: 1px solid black;"><b>TGL <br> KONFIRMASI</b></td>
            <td style="width: 12%;vertical-align:middle; border: 1px solid black;"><b>NOMINAL<br> PENGAJUAN </b></td>
            <td style="width: 13%;vertical-align:middle; border: 1px solid black;"><b>TGL <br> REALISASI</b></td>
            <td style="width: 12%;vertical-align:middle; border: 1px solid black;"><b>NOMINAL <br> PENCAIRAN</b></td>
            <td style="width: 9%;vertical-align:middle; border: 1px solid black;"><b>PENERIMA MANFAAT</b></td>
        </tr>
    </thead>

    <tbody>
        @if (count($programs) > 0)
            @foreach ($programs as $pilar => $details)
                @php
                    $jumlah_nominal_pengajuan = 0;
                    $jumlah_nominal_pencairan = 0;
                    $jumlah_penerima_manfaat = 0;
                @endphp
                {{-- foreach menghitung total --}}
                @foreach ($details as $x)
                    @php
                        $jumlah_nominal_pengajuan += $x->nominal_pengajuan;
                        $jumlah_nominal_pencairan += $x->nominal_pencairan;
                        $jumlah_penerima_manfaat += $x->jumlah_penerima;
                    @endphp
                @endforeach

                <tr style="background-color:#cbf2d6; text-align: left; page-break-inside: avoid;">
                    <td style="width: 54%;vertical-align:middle;padding-left:3.0mm;border-left: 1px solid black;border-bottom: 1px solid black;"
                        colspan="4">
                        <b>{{ strtoupper(chr(64 + $loop->iteration)) }}. {{ $pilar }} </b>
                    </td>

                    <td style="width: 12%;vertical-align:middle;border-bottom: 1px solid black; text-align:center; ">
                        <b>Rp{{ number_format($jumlah_nominal_pengajuan, 0, '.', '.') }},-</b>
                    </td>
                    <td style="width: 13%;border-bottom: 1px solid black; text-align:center; "></td>
                    <td style="width: 12%;vertical-align:middle;border-bottom: 1px solid black; text-align:center; ">
                        <b>Rp{{ number_format($jumlah_nominal_pencairan, 0, '.', '.') }},-</b>
                    </td>
                    <td
                        style="width: 9%;vertical-align:middle;border-right: 1px solid black; text-align:center; border-bottom: 1px solid black;">
                        <b>{{ $jumlah_penerima_manfaat }}</b>
                    </td>
                </tr>

                @php
                    $uniquePrograms = $details->unique('nama_program');
                @endphp

                {{-- foreach data --}}
                @foreach ($uniquePrograms as $a)
                    @php
                        // Anda mungkin perlu menyesuaikan ini tergantung pada struktur model dan propertinya
                        $firstDetail = $details->where('nama_program', $a->nama_program)->first();
                    @endphp

                    <tr style="background-color:#e6e6e6; text-align: left; page-break-inside: avoid;">
                        <td style="width: 54%;vertical-align:middle;padding-left:3.0mm;border-left: 1px solid black;border-bottom: 1px solid black;"
                            colspan="4">
                            <b>{{ $loop->iteration }}.
                                {{ app\Http\Controllers\PrintPengajuanController::get_nama_program($firstDetail->id_program_kegiatan) }}
                            </b>
                        </td>

                        <td style="width: 12%;vertical-align:middle;border-bottom: 1px solid black;text-align:center;">
                            <b>Rp{{ number_format($details->where('nama_program', $a->nama_program)->sum('nominal_pengajuan'), 0, '.', '.') }},-</b>
                        </td>
                        <td style="width: 13%;border-bottom: 1px solid black;text-align:center;"></td>
                        <td style="width: 12%;vertical-align:middle;border-bottom: 1px solid black;text-align:center;">
                            <b>Rp{{ number_format($details->where('nama_program', $a->nama_program)->sum('nominal_pencairan'), 0, '.', '.') }},-</b>
                        </td>
                        <td
                            style="width: 9%;vertical-align:middle;border-right: 1px solid black;text-align:center;border-bottom: 1px solid black;">
                            <b>{{ $details->where('nama_program', $a->nama_program)->sum('jumlah_penerima') }}</b>
                        </td>
                    </tr>

                    @foreach ($details->where('nama_program', $a->nama_program) as $b)
                        <tr style=" page-break-inside: avoid;">
                            <td
                                style="width: 3%;border-bottom: 1px solid black;border-left: 1px solid black; vertical-align:top;padding-left:7mm;border-right:none;text-align:center;">{{ $loop->iteration }}</td>
                            <td
                                style="width: 20%;vertical-align:middle; border-bottom: 1px solid black;border-right: 1px solid black; text-align:left;border-left:none;">{{ $b->pengajuan_note }}
                            </td>
                    
                            <td style="width: 18%;vertical-align:middle; border: 1px solid black; text-align:center;">{{ $b->sumber_dana_opsi }} - {{ App\Models\Rekening::where('id_rekening', $b->id_rekening)->value('no_rekening') }}
                            </td>
                                  @php
                                    $tgl_konfirmasi = App\Models\Pengajuan::where('id_pengajuan', $b->id_pengajuan)->value('tgl_konfirmasi');
                                    $tgl_terbit_rekomendasi = App\Models\Pengajuan::where('id_pengajuan', $b->id_pengajuan)->value('tgl_terbit_rekomendasi');
                                @endphp
                            <td style="width: 13%;border: 1px solid black; vertical-align:middle;text-align:center;">{{ Carbon\Carbon::parse($tgl_konfirmasi)->isoFormat('D/M/Y') }}
                            </td>
                            <td style="width: 12%;border: 1px solid black; vertical-align:middle;text-align:center;">Rp{{ number_format($b->nominal_pengajuan, 0, '.', '.') }},-
                            </td>
                            <td style="width: 13%;border: 1px solid black; vertical-align:middle;text-align:center;">{{ Carbon\Carbon::parse($tgl_terbit_rekomendasi)->isoFormat('D/M/Y') }}
                            </td>
                            <td style="width: 12%;border: 1px solid black; vertical-align:middle;text-align:center;">Rp{{ number_format($b->nominal_pencairan, 0, '.', '.') }},-
                            </td>
                            <td style="width: 9%;border: 1px solid black; vertical-align:middle;text-align:center;">{{ $b->jumlah_penerima ?? '0' }}
                            </td>
                        </tr>
                    @endforeach
                @endforeach
            @endforeach
        @else
            <tr>
                <td colspan="8" style="border: 1px solid black; vertical-align:top;padding-left:7mm;">
                    Tidak Ada Data
                </td>
            </tr>
        @endif
    </tbody>

</table>
