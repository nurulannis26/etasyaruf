@extends('errors::minimal419')

@section('title','Sesi Akses Habis')
@section('code', '419')
@section('message','Sesi Anda berakhir karena tidak ada aktivitas penggunaan sistem selama 2 jam.')
@section('bottom','Silahkan Login ulang dengan klik tombol berikut :')
@section('login','Login')
