@extends('errors::minimal419')

@section('title', 'Server Maintenance')
@section('code', '500')
@section('message', 'Sayangnya saat ini server sedang dalam perbaikan.')
@section('bottom', 'Silahkan coba lagi dengan klik tombol berikut :')
@section('refresh', 'Refresh')
