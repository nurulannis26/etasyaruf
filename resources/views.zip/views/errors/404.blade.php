@extends('errors::minimal419')

@section('title','Halaman Tidak Ditemukan')
@section('code', '404')
@section('message','Halaman yang Anda cari tidak ada atau sudah dipindahkan.')
@section('bottom','Silahkan kembali dengan klik tombol berikut :')
@section('btn','Kembali')
