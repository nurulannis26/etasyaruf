@extends('errors::minimal419')

@section('title','Akses Ditolak')
@section('code', '403')
@section('message','Halaman yang Anda coba akses memiliki hak akses terbatas.')
@section('bottom','Silahkan kembali dengan klik tombol berikut :')
@section('btn','Kembali')
