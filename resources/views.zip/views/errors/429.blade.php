@extends('errors::minimal419')

@section('title','Terlalu Banyak Permintaan')
@section('code', '429')
@section('message','Server menerima terlalu banyak permintaan akses.')
@section('bottom','Silahkan coba lagi dengan klik tombol berikut :')
@section('refresh','Refresh')
