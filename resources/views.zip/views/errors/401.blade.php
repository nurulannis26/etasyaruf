@extends('errors::minimal419')

@section('title','Belum Login')
@section('code', '401')
@section('message','Halaman yang Anda coba akses harus login dahulu.')
@section('bottom','Silahkan kembali dengan klik tombol berikut :')
@section('btn','Kembali')
