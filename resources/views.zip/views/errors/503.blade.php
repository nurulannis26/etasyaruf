@extends('errors::minimal419')

@section('title', 'Layanan Dalam Proses Update')
@section('code', '503')
@section('message', 'Tunggu sebentar ya sedang diupdate 🙂')

@section('bottom', 'Perkiraan waktu update: 13.00- 14.00 WIB')
{{-- @section('btn', 'Kembali') --}}
