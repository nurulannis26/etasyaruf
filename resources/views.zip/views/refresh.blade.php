<!DOCTYPE html>
<html>

<head>
    <title>Loading</title>
</head>

<body>
    <h1>Loading...</h1>

    <script type="text/javascript">
        // Menggunakan setTimeout untuk melakukan reload halaman setelah 2 detik (2000 milidetik)
        setTimeout(function() {
            location.reload();
        }, 2000); // 2000 milidetik = 2 detik
    </script>
</body>

</html>
